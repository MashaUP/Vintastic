<p align="center"><img src="assets/logo-512.png" width="120" alt="Logo Vintastic"></p>

<h1 align="center">Vintastic</h1>

<p align="center">
  Assistente per Vinted, per Chrome, Edge e Brave: scanner degli armadi, campagne di like, offerte e messaggi privati con il <b>tuo</b> account,<br>
  code modificabili mentre girano, Smart Offer Engine, dashboard, diagnostica. <b>Non acquista mai nulla.</b>
</p>

<p align="center">
  <a href="https://github.com/MashaUP/Vintastic/releases/latest"><img alt="Release" src="https://img.shields.io/github/v/release/MashaUP/Vintastic?color=8f6ef2&label=release"></a>
  <a href="https://github.com/MashaUP/Vintastic/actions/workflows/ci.yml"><img alt="CI" src="https://img.shields.io/github/actions/workflow/status/MashaUP/Vintastic/ci.yml?label=test"></a>
  <img alt="Manifest V3" src="https://img.shields.io/badge/Manifest-V3-7c5cf0">
  <img alt="Licenza MIT" src="https://img.shields.io/badge/licenza-MIT-d94f8c">
  <a href="https://discord.gg/EPsbQCuAkx"><img alt="Discord" src="https://img.shields.io/badge/Discord-community-5865F2"></a>
  <a href="https://ko-fi.com/mashaup"><img alt="Ko-fi" src="https://img.shields.io/badge/Ko--fi-supporta-ff5e5b"></a>
</p>

<p align="center"><img src="docs/screenshots/dashboard.png" width="860" alt="Dashboard di Vintastic"></p>

---

## Indice

[Cosa fa](#cosa-fa) · [Stato del progetto](#stato-del-progetto) · [Installazione](#installazione) · [Primi passi](#primi-passi) · [Configurazione](#configurazione) · [Aggiornamenti](#aggiornamenti) · [Release](#release) · [Discord](#discord) · [Sicurezza](#sicurezza-e-privacy) · [FAQ](#faq) · [Documentazione](#documentazione) · [Supporto](#supporto) · [Credits](#credits)

## Cosa fa

| | |
|---|---|
| **Scanner degli armadi** | Legge tutti gli annunci di un venditore (paginazione, nessun doppione, aggiornamento dei dati, storico prezzi, annunci ripubblicati collegati). Date separate: pubblicazione, aggiornamento, ripubblicazione, data della foto. Mai inventate. |
| **Filtri e Top N** | Ultimi 5/10/20/50/100 o un numero a scelta, ultime 24 ore / 2, 3, 7, 14, 30 giorni / intervallo, combinabili. Prezzo, stato, venditore, «escludi già fatti». Ordine ribaltabile (più recenti o meno recenti in cima). Filtri salvabili. Vinted non dà la data di pubblicazione: si usa la data della foto (stima) e poi l'ordine dell'armadio. |
| **Campagne** | Like, offerte e messaggi privati, singoli o combinati, nell'ordine che scegli; timer configurabili (tra operazioni, tra annunci, tra tipi); conferma facoltativa per ogni offerta; simulazione (Dry Run). |
| **Messaggi privati** | «Chiedi info» sull'annuncio, testo nella chat, invio **automatico (A)** o **premuto da te (B)**. Solo verso i **destinatari autorizzati** che scegli tu (i tuoi account, gli amici che ti hanno dato l'ok): agli altri venditori niente. Testo predefinito, modello, scritto ora, a rotazione o casuale tra modelli, domanda sull'annuncio; segnaposto `{titolo}` `{prezzo}` `{marca}` `{taglia}` `{venditore}`; modificabile annuncio per annuncio. Conta come inviato solo quando compare nella conversazione. |
| **Menu Venditore** | Quando aggiungi annunci a una coda scegli tra gli **account che segui** su Vinted e i **destinatari dei messaggi**, anche se non li hai ancora scansionati: Vintastic legge prima il loro armadio. |
| **Code dinamiche** | Aggiungi annunci e operazioni, rimuovi, modifica, cambia priorità, riordina (anche casuale, con anteprima) **mentre la campagna gira**. Le operazioni completate non si toccano. Ogni modifica è nello storico. |
| **No Repeat** | Global Interaction Ledger: lo stesso account non ripete per sbaglio lo stesso like, la stessa offerta o lo stesso messaggio sullo stesso annuncio, in nessuna campagna. Separato per tipo. Un esito incerto non si ripete mai. Per rifare apposta: **Azzera storico** (dalla campagna, dagli Annunci o con un clic sul chip «Like ×»), solo like, solo offerte, solo messaggi o un mix; oppure **Nuovo ciclo**. Se il like c'è già su Vinted viene tolto e rimesso (o lasciato, a scelta per campagna). |
| **Cicli** | Riprocessa gli annunci già elaborati (uno, alcuni, tutti) in un **nuovo ciclo**, quando vuoi: mattina, pomeriggio, giorno dopo. Prima vedi esattamente cosa si ripete, poi confermi e approvi. La cronologia dei cicli precedenti resta. |
| **Errori isolati** | Un problema di un tipo (per esempio la chat che non si apre) sospende solo quel tipo nella campagna: like e offerte continuano. Un'operazione che non parte si riprova più tardi senza bloccare le altre. |
| **Smart Offer Engine** | Predefinito **+5% sul prezzo**; percentuale ± (sotto o sopra il prezzo), Risparmio / Interazione / Personalizzata, sconti e incrementi in % o €, minimo e massimo, fasce di prezzo, arrotondamenti (,99 · ,00 · multipli di 5 e 10, per eccesso/difetto/vicino), importi casuali. Anteprima sempre. |
| **Domande al venditore** | Domande pertinenti all'annuncio (es. giacca → «Potresti indicarmi la misura delle spalle?»), più alternative, tono e lingua, cronologia. Regole locali o LLM (locale o esterno) a scelta. Si copiano o si salvano come modelli di messaggio. |
| **Mini-widget e FAB** | Sulle pagine Vinted: avanzamento in tempo reale, timer, pausa/riprendi/stop; menu rapido per scansionare l'armadio o aggiungere l'annuncio aperto. |
| **Dashboard** | Statistiche con filtri temporali, grafici, attività in tempo reale, riepilogo code, stato del sistema; widget personalizzabili, tema chiaro/scuro, ricerca globale, comando rapido (Ctrl+K), scorciatoie. |
| **Sicurezza** | Policy Validator prima dell'avvio, Preview Snapshot, soglie giornaliere, Kill Switch globale e per modulo, circuit breaker, pausa su 403/429/CAPTCHA, auto-pausa senza rete, autenticazione assistita. |
| **Affidabilità** | IndexedDB con journal write-ahead: dopo un crash niente viene ripetuto alla cieca (ciò che era in invio diventa «da verificare»). Recovery Center. Migrazioni versionate con rollback. |
| **Diagnostica** | Log filtrabili con possibile soluzione, Health Center con «Esegui controllo completo», Support Bundle senza dati sensibili. |
| **Notifiche** | Centro notifiche con priorità e raggruppamento, notifiche di sistema, badge; pulitore delle notifiche Vinted (solo «segna come letta»). |
| **Aggiornamenti** | «Cerca aggiornamento» da `version.json` nel repository, download con verifica SHA-256, installazione guidata. Release automatiche con GitHub Actions. |

<p align="center"><img src="docs/screenshots/campagna.png" width="49%" alt="Dettaglio campagna"> <img src="docs/screenshots/popup.png" width="24%" alt="Popup"> <img src="docs/screenshots/widget.png" width="24%" alt="Mini-widget"></p>

## Stato del progetto

| | |
|---|---|
| Versione | **2.2.1** |
| Browser | Chrome, Edge, Brave (Chromium ≥ 116). Provato in automatico su **Chrome 153**; Edge e Brave non sono stati provati in questo ciclo |
| Verificato su Vinted reale | **In parte**: scansione e like provati dall'autore su vinted.it. Per «Chiedi info» sono verificati il pulsante, il clic e l'apertura della chat con il campo del messaggio (07–08/11/2026), e misurato il ritardo con cui il pulsante diventa cliccabile (causa del problema della 2.0.0); **l'invio di un messaggio con Vintastic su Vinted reale non è ancora stato provato**. Lettura degli account seguiti provata su vinted.it (sola lettura). Offerte e notifiche sono ricostruite (vedi [TEST_PLAN](docs/TEST_PLAN.md)) |
| Dipendenze a runtime | Nessuna. Nessun passaggio di build per usarla |
| Test | `npm test`: controlli, ESLint e 93 test unitari (logica, migrazioni IndexedDB, divieto d'acquisto, messaggi, cicli, menu Venditore, storico, aggiornamenti) · `npm run test:e2e`: 35 scenari in Chrome con l'estensione caricata e un Vinted finto |

## Installazione

1. Scarica **`Vintastic-x.y.z.zip`** dall'[ultima release](https://github.com/MashaUP/Vintastic/releases/latest) (oppure dalla radice del repository).
2. Estrailo in una **cartella stabile** (non nella cartella temporanea dei download). La cartella giusta è quella che contiene `manifest.json`.
3. Apri `chrome://extensions` (o `edge://extensions`, `brave://extensions`) e attiva **Modalità sviluppatore**.
4. **Carica estensione non pacchettizzata** › scegli la cartella `Vintastic`.
5. Si apre la **guida iniziale**: segui i 9 passi (la prima campagna è una simulazione).
6. Facoltativo: fissa l'icona di Vintastic nella barra del browser.

## Primi passi

1. **Accedi a Vinted** nel browser: Vintastic riconosce l'account da solo (legge solo l'id utente, mai token o password).
2. **Scanner** › incolla l'URL di un armadio (`https://www.vinted.it/member/123…`) › Avvia. Oppure, sull'armadio, pulsante Vintastic › «Scansiona questo armadio».
3. **Annunci** › filtra (es. «Ultimi 20» + «Ultimi 7 giorni») › seleziona › **Aggiungi a campagna**.
4. **Campagne** › apri › **Anteprima e approvazione** (controlli, importi delle offerte, testi dei messaggi) › **Avvia**.
5. Segui l'avanzamento dal widget su Vinted, dal popup o dalla dashboard. Puoi chiudere tutto: la coda continua finché il browser è aperto.

Le nuove campagne partono in **Simulazione**. Per la modalità reale togli la spunta nelle impostazioni della campagna e riapprova l'anteprima.

## Configurazione

Tutto in **Impostazioni** (si salva subito, solo nel tuo browser):

- **Timer**: secondi tra operazioni dello stesso annuncio (predefinito 3–8), tra annunci (10–25), tra tipi (like → offerta…, 3–8), minimo assoluto (2). Ogni campagna può avere i suoi.
- **Messaggi**: destinatari autorizzati (ID o link del profilo, anche da un armadio scansionato; senza limite di numero), modalità predefinita A/B, attesa dell'invio manuale (fino a 4 minuti), messaggio predefinito e modelli.
- **Limiti**: soglie giornaliere per like, offerte, messaggi (predefinito 10), per account e complessive; pause dopo 403/429. *Sono soglie tue, non limiti ufficiali di Vinted.*
- **Avanzate**: errori di fila dello stesso tipo prima di sospendere quel tipo (3), di qualsiasi tipo prima della pausa (6), tentativi di un'operazione che non parte (3).
- **Notifiche**: categorie, durata, notifiche di sistema.
- **FAB e widget**: attivi, dimensione, posizione.
- **AI**: regole locali (predefinito) o endpoint compatibile OpenAI (Ollama/LM Studio in locale, o un servizio esterno).
- **Discord**: webhook personale facoltativo (Impostazioni › Discord spiega come crearlo).
- **Backup**: esporta/importa JSON con anteprima, scelta delle parti e backup automatico.
- **Dati**: conservazione di log, notifiche, attività.
- **Scorciatoie**: `Alt+Shift+V` dashboard · `Alt+Shift+P` pausa/ripresa · `Alt+Shift+K` Kill Switch (modificabili in `chrome://extensions/shortcuts`). Nella dashboard: `Ctrl+K`, `/`, `Alt+1…9`, `?`.

## Aggiornamenti

1. Popup o dashboard › **Cerca aggiornamento** (anche in automatico ogni 12 ore, disattivabile).
   Vintastic legge `version.json` dal repository GitHub: la nuova versione si vede appena è caricata, anche prima della release.
2. **Salute › Scarica e verifica**: `Vintastic-x.y.z.zip` viene scaricato in Download/Vintastic e confrontato con lo SHA-256 di `version.json`; se non coincide non viene salvato.
3. Estrai lo zip **sopra** la cartella attuale (sostituisci i file), poi **Installa**: Vintastic si ricarica e recupera le campagne. Se hai già estratto i file ma non hai ricaricato, Salute te lo dice.

Un'estensione caricata da cartella non può sostituire da sola i propri file: l'estrazione la fai tu. Dal Chrome Web Store l'aggiornamento sarebbe automatico (Vintastic non è sul Web Store).

## Release

Le release sono automatiche: scrivi titolo e descrizione, scegli il tag `vX.Y.Z`, pubblica. GitHub Actions esegue i test, crea `vintastic-X.Y.Z.zip` e il suo `.sha256`, li allega alla release, conserva gli artifact e (se configurato) avvisa su Discord. Dettagli in [RELEASE.md](docs/RELEASE.md).

## Discord

- **Release su Discord**: secret `DISCORD_WEBHOOK_URL` nel repository → notifica a ogni release.
- **Notifiche dall'estensione** (facoltative): il *tuo* webhook, salvato solo nel tuo browser, con permesso concesso da te.
- Community: **[discord.gg/EPsbQCuAkx](https://discord.gg/EPsbQCuAkx)** (il link si aggiorna da `links.json` senza nuove versioni).

## Sicurezza e privacy

- **Divieto assoluto di acquisto**: nessun carrello, checkout o pagamento. Ogni richiesta verso Vinted passa da una lista chiusa (lettura, like, offerta, notifiche); tutto il resto viene bloccato prima di partire. Anche i clic dei messaggi («Chiedi info», Invia) passano dal guard. Test dedicati a ogni versione.
- **Messaggi solo a chi vuoi tu**: elenco dei destinatari autorizzati, controllato nell'anteprima, dal motore e sulla pagina prima del clic. Nessun endpoint di messaggistica: solo i controlli visibili della chat. I testi non finiscono nei log né nel Support Bundle.
- **Nessun aggiramento**: CAPTCHA, verifiche, 403/429 e restrizioni fermano tutto e passano la mano a te.
- **Nessuna credenziale**: Vintastic non legge né salva password, codici, cookie o token (legge solo l'id numerico dell'utente). I token di sessione restano in memoria e non finiscono in log, backup o Support Bundle.
- **Nessun server**: i dati restano nel browser. Uscite solo verso GitHub (aggiornamenti/link) e, se li attivi tu, AI esterna e Discord.

Dettagli: [SECURITY.md](SECURITY.md). Vintastic è un progetto indipendente, non affiliato a Vinted. Usalo rispettando i termini del servizio di Vinted.

## FAQ

<details><summary><b>Può comprare qualcosa per sbaglio?</b></summary>No. Non esiste nessun percorso d'acquisto nel codice, e un guard blocca qualsiasi richiesta non in lista prima che parta.</details>
<details><summary><b>Dove sono finiti i commenti?</b></summary>Tolti nella 2.0.0: Vinted non ha commenti pubblici sugli annunci. Per scrivere al venditore c'è l'operazione «Messaggio privato»; le campagne vecchie vengono migrate senza i commenti.</details>
<details><summary><b>Come rifaccio le stesse operazioni più tardi?</b></summary>Nella campagna: «Nuovo ciclo…» (o l'icona sull'annuncio). Vedi l'elenco di cosa si ripete e cosa no, confermi, approvi l'anteprima e avvii. Le operazioni da verificare non si ripetono mai da sole. Vinted tiene un solo like per annuncio: se il like c'è ancora, viene registrato come già presente.</details>
<details><summary><b>Un messaggio non va: si ferma tutto?</b></summary>No. Si riprova più tardi e intanto partono le altre operazioni; dopo 3 errori di fila i messaggi della campagna vengono sospesi e like e offerte continuano. Il messaggio d'errore dice cosa è successo (clic senza effetto, campo assente, scheda in background…).</details>
<details><summary><b>A chi può scrivere Vintastic?</b></summary>Solo ai venditori nell'elenco di Impostazioni › Messaggi. Se in una campagna c'è un annuncio di qualcun altro, il messaggio viene saltato senza aprire la chat (like e offerte su quell'annuncio restano). Con l'elenco vuoto le campagne con messaggi non partono.</details>
<details><summary><b>Modalità A o B?</b></summary>A: Vintastic preme Invia e aspetta di vedere il messaggio nella conversazione. B: Vintastic apre la chat, scrive il testo e porta la scheda in primo piano; premi tu Invia (puoi anche cambiare il testo). Se in B non premi Invia entro il tempo scelto, il messaggio non parte e i messaggi della campagna si sospendono (il resto continua). Per la prima prova usa B.</details>
<details><summary><b>Un messaggio è «da verificare»?</b></summary>Vintastic ha premuto Invia (o il campo si è svuotato) ma il messaggio non è comparso nella conversazione. Non viene mai rimandato da solo: apri la chat su Vinted e indica in Recupero se c'è.</details>
<details><summary><b>Funziona con la scheda in secondo piano o il browser chiuso?</b></summary>Like e offerte sì: Vintastic usa una sua scheda di Vinted, che può restare dietro le altre. Per i messaggi la scheda passa in primo piano (si può disattivare in Impostazioni › Messaggi). A browser chiuso no; alla riapertura la coda si recupera.</details>
<details><summary><b>Una operazione è «da verificare». Che faccio?</b></summary>Recupero › controlla su Vinted e indica se è stata eseguita. Per i like c'è la verifica automatica. Non viene mai ripetuta da sola.</details>
<details><summary><b>Posso usare più account?</b></summary>Vintastic usa l'account con cui sei collegato a Vinted, riconosce quelli usati in passato e controlla che la sessione corrisponda alla campagna. Il cambio di account si fa su Vinted.</details>
<details><summary><b>Le soglie giornaliere sono «sicure»?</b></summary>Sono soglie tue. Vinted non pubblica i suoi limiti, e nessun numero è garantito.</details>

## Documentazione

[Architettura](docs/ARCHITECTURE.md) · [Test](docs/TEST_PLAN.md) · [Release](docs/RELEASE.md) · [Sicurezza](SECURITY.md) · [Changelog](CHANGELOG.md)

## Supporto

- Community e aiuto: **[Discord](https://discord.gg/EPsbQCuAkx)**
- Bug: [apri una segnalazione](https://github.com/MashaUP/Vintastic/issues/new?template=segnalazione-bug.yml) e allega il **Support Bundle** (Log › Support Bundle)
- Se ti è utile: **[Ko-fi](https://ko-fi.com/mashaup)** ☕

## Credits

Progetto di **MashaUP**. Riusa idee e codice dei suoi progetti [Vinted_Relist](https://github.com/MashaUP/Vinted_Relist) (lettura dei token di sessione, gestione 403/429, esiti incerti, version checker, link centralizzati) e Keep_Watching (Health Center, cronologia eventi, statistiche locali). Nessuna libreria di terze parti a runtime. Licenza [MIT](LICENSE).

